package com.example.gouravsproject;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static java.sql.Types.VARCHAR;

public class addPage extends AppCompatActivity {
    EditText subject,marks, roll;
    DatabaseHelperUser db;
    Button additon,viewB;
//    DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_add_page);
        db = new DatabaseHelperUser(this);
        roll = (EditText) findViewById(R.id.rollEditText);
        subject = (EditText)findViewById(R.id.subjectEditText);
        marks = (EditText)findViewById(R.id.marksEditText);
        additon = (Button) findViewById(R.id.addButton);
        viewB = (Button) findViewById(R.id.viewButton);
         addData();
         viewBut();

    }
    public void update(View view)
    {
        Intent intent = new Intent(this,updatePage.class);
        startActivity(intent);
    }
    public void addData(){
        additon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isInserted = db.insertData(subject.getText().toString(),roll.getText().toString(),marks.getText().toString());
                if( isInserted == true)
                {
                    Toast.makeText(addPage.this, "your data has been sucessfully inserted into the database", Toast.LENGTH_SHORT).show();
                }
                else Toast.makeText(addPage.this, "sorry unable to insert data into the database", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void viewBut()
    {
        viewB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = db.getAllData();
                if (res.getCount() == 0)
                {
                    showMessage("Error","no data found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                buffer.append("ROLL NO.         ");
                buffer.append("SUBJECT        ");
                buffer.append("MARKS                 ");
                while(res.moveToNext())
                {
                    buffer.append(res.getString(2)+"       ");
                    buffer.append(res.getString(1)+"              ");
                    buffer.append(res.getString(3)+"\n");
                }
                showMessage("STUDENTRESULT DATABASE",buffer.toString());

            }

        });
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }


}