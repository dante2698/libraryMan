package com.example.gouravsproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class studentLogin extends AppCompatActivity {
    private TextView userName;
    private TextView passWord;
    TextView loginTextView;
    ImageView iv;
    Button signUp;
    private FirebaseAuth mAuth;
    public void loginButtonCllcked(View view) {
        Intent intent = new Intent(this,loginActivity.class);
        startActivity(intent);
    }

    public void sup(View view) {
        String email = userName.getText().toString();
        String password = passWord.getText().toString();
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Toast.makeText(studentLogin.this, "hurray you have signed in", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            nextActivity();
                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(studentLogin.this, "oops! something went wrong try again", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }
    public void nextActivity()
    {
        Intent intent = new Intent(this,resultPage.class);
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_student_login);
        iv = (ImageView) findViewById(R.id.iv);
        userName = (TextView) findViewById(R.id.userTextView);
        passWord = (TextView) findViewById(R.id.passwordTextView);
        loginTextView =(TextView)findViewById(R.id.signUpTextView);
        signUp =(Button)findViewById(R.id.log);
        mAuth = FirebaseAuth.getInstance();
    }
}
