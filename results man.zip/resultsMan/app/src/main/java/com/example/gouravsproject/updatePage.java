package com.example.gouravsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class updatePage extends AppCompatActivity {
    EditText roll,id,sub,mark;
    Button updata;
    DatabaseHelperUser db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_update_page);
        db = new DatabaseHelperUser(this);
        roll = findViewById(R.id.rollEditText);
        //id = findViewById(R.id.idEditText);
        sub = findViewById(R.id.subjectEditText);
        mark =findViewById(R.id.marksEditText);
     updateData();

    }
    public void update(View view)
    {
        Intent intent = new Intent(this,addPage.class);
        startActivity(intent);
    }
    public void updateData()
    {
        updata = findViewById(R.id.updateButton);
        updata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isUpdate = db.updataData(sub.getText().toString(),roll.getText().toString(),mark.getText().toString());
                if (isUpdate == true)
                {
                    Toast.makeText(updatePage.this, "data is updated", Toast.LENGTH_SHORT).show();
                }
                else Toast.makeText(updatePage.this, "update operation failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
