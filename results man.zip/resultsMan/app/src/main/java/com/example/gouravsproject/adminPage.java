package com.example.gouravsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class adminPage extends AppCompatActivity {
    Button userAdd,userUpdate,userDelete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_admin_page);
        userAdd = findViewById(R.id.bt1);
        userDelete = findViewById(R.id.bt2);
        userUpdate = findViewById(R.id.bt3);
    }
    public void add(View view)
    {
        Intent intent = new Intent(this,addPage.class);
        startActivity(intent);
    }
    public void update(View view)
    {
        Intent intent = new Intent(this,updatePage.class);
        startActivity(intent);
    }
    public void delete(View view) {
        Intent intent = new Intent(this, deletePage.class);
        startActivity(intent);
    }
}
