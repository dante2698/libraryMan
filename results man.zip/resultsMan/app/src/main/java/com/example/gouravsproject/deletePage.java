package com.example.gouravsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class deletePage extends AppCompatActivity {
    EditText Roll;
    Button del;
    DatabaseHelperUser db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_delete_page);
        Roll = (EditText)findViewById(R.id.rollEditText);
        del = (Button)findViewById(R.id.deleteButton);
        db = new DatabaseHelperUser(this);
        delete();
    }
    public void delete()
    {
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer del = db.deleteData(Roll.getText().toString());
                if(del > 0 )
                {
                    Toast.makeText(deletePage.this, "The User " + Roll.getText().toString()+" has been deleted",Toast.LENGTH_SHORT).show();
                }
                else Toast.makeText(deletePage.this, "No user with ROll NUMBER:" + Roll.getText().toString() + " Exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
